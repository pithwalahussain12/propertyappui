import {createBrowserHistory} from 'History'

export default{createBrowserHistory}(
    
)