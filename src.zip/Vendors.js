import React, {Component} from 'react'
import './App.css';


const Vendors=()=>{
    return(
        <div className="">
            ckjdscviydscdsu tcv
        </div>
    )
}

export default Vendors;