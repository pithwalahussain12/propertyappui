import React, {Component} from 'react'
import './App.css';
import {Link} from 'react'

const Login=()=>{
    return(
        <div className="Login-page">
              vfvfdv vfvfdv vfvfdv    
        </div>
    )
}

export default Login;



